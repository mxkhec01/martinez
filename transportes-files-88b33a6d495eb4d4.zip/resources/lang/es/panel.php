<?php

return [
    'site_title' => 'Transportes',
];
